# Toolvantas Tool #3 — Freelance Income Calculator

Status: local deliverables prepared; not uploaded or deployed by ChatGPT.

## Deliverables
- `freelance-income-calculator.html` — the calculator page.
- `tools.html` — directory updated to list the locked Freelance Project Pricing Calculator, the new Freelance Income Calculator, and the existing Freelance Hourly Rate Calculator as separate tools.
- `sitemap.xml` — includes the home page, tool directory, and all three calculator URLs.
- `robots.txt` — allows crawling and declares the sitemap URL.

## Research and product decisions
- The target phrase is “Freelance Income Calculator.” User-provided third-party keyword screenshot estimated 40 searches/month, CPC $30.35, and low ad competition. These are third-party estimates, not verified Google Keyword Planner values; CPC is not a promise of earnings or organic ranking.
- Related phrases included freelance income calculator app, freelance calculator tax, self-employed income calculator, freelance salary calculator, freelance day rate calculator, freelance income meaning, and how to report freelance income.
- The tool estimates monthly/annual take-home income after platform percentage fees, payment percentage fees, fixed payout fees, business expenses, and a user-selected tax reserve.
- Currency selection changes formatting only; it does not perform foreign-exchange conversion.
- The tax percentage is a user-selected planning reserve, not jurisdiction-specific tax advice.
- This tool is distinct from project quote pricing and hourly/day rate planning.
- `index.html` and the locked project pricing calculator file were not modified.

## Verification performed
- JavaScript logic was executed in a Node-based DOM mock harness: 12/12 scenarios passed (default values, zero gross, zero deductions, 100% tax reserve, 100% platform fee, expenses exceeding income, invalid negative value, value above maximum, reset, BDT display, empty numeric input, and fixed-fee loss/tax-reserve handling).
- Static HTML parsing confirmed: one H1; unique IDs; every form control has a label; no missing in-page anchor targets; canonical URL and meta description present; WebApplication JSON-LD parses; four FAQ entries; mobile breakpoints present; no inline event-handler attributes.
- Default result: $2,775.25 estimated monthly take-home and $33,303.00 annualized.
- The source page is 12,820 characters. Live HTTP status, headers, external browser interaction, accessibility screen-reader behavior, sitemap fetch/indexing, and production deployment could not be independently verified from this environment. Do not claim those checks passed until verified after upload.

## Install order
1. Upload `freelance-income-calculator.html`.
2. Upload the updated `tools.html`.
3. Upload the updated `sitemap.xml` and `robots.txt`.
4. Do not change `index.html` as part of this tool task.
5. After deployment, test each calculator URL and confirm the directory links, sitemap URL, and robots sitemap declaration resolve correctly.

## Lock criteria
The local calculation and static checks passed. Final production lock should wait until the user uploads these files and confirms the deployed pages work, because ChatGPT did not upload or deploy them.
