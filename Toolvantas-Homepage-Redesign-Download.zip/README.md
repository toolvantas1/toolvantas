# Toolvantas — Hybrid Homepage Redesign (Phase 01)

Static HTML/CSS/JS foundation for a separate general-purpose tools website.

## Direction
Hybrid: established utility-site usability with distinctive modern design. The homepage emphasizes direct tool/category discovery, a practical featured-tool panel, restrained colors, and responsive layout.

## Files
- `index.html` — redesigned homepage
- `tools.html` — initial directory placeholder
- `assets/css/site.css` — responsive design system and page styles
- `assets/js/site.js` — mobile navigation and year helper
- `robots.txt`, `sitemap.xml` — placeholders only; verify and update before production
- `PROJECT-STATUS.md` — project separation, approved first-tool research, and continuation notes

## Important status
This is a design iteration, not a deployed website. The freelance calculator is still in development and is not functional in this package. The sitemap contains a placeholder URL and must not be submitted to search engines as-is.

## Local preview
Open `index.html` in a browser. For more reliable path behavior, serve the folder using a local static HTTP server.
